package com.example.my_work

import android.content.Context
import org.chromium.base.task.TaskPriority

data class TodoItem(val id: Int,
                    val task: String,
                    var isCompleted: Boolean = false
)


