package com.example.my_work

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

private val Context.dataStore by preferencesDataStore("todo_preferences")
private val TASKS_KEY = stringSetPreferencesKey("tasks_key")
val Context.settingsDataStore by preferencesDataStore("settings")
private val PRIORITY_KEY = stringSetPreferencesKey("priority_key")

data class Task(
    val id: Int,
    val task: String,
    val priority: TaskPriority = TaskPriority.RANDOM,
    var isCompleted: Boolean = false
)
enum class TaskPriority(val displayName : String , val color: Color) {
    IMPORTANT("Important",Color.Red),
    STUDY("Study" ,Color.Blue),
    HEALTH("Health" , Color.Magenta),
    RANDOM("Random" , Color.Gray)
}

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            getSavedTasks(applicationContext).collect { savedTasks ->
                val todos = savedTasks.toMutableList()
                setContent {
                    LineUpApp()
                    TodoApp(
                        initialTasks = todos,
                        onSaveTasks = { tasks ->
                            lifecycleScope.launch {
                                saveTasks(applicationContext, tasks)
                            }
                        }
                    )
                }
            }
        }
    }
}


private suspend fun saveTasks(context: Context, tasks: List<Task>) {
    context.dataStore.edit { preferences ->
        val taskStrings = tasks.map { "${it.id}|${it.task}|${it.priority.name}|${it.isCompleted}" }
        preferences[TASKS_KEY] = taskStrings.toSet()
    }
}

fun getSavedTasks(context: Context): Flow<List<Task>> {
    return context.dataStore.data.map { preferences ->
        preferences[TASKS_KEY]?.mapIndexed { index, taskString ->
            val parts = taskString.split("|")
            Task(
                id = parts[0].toInt(),
                task = parts[1],
                priority = TaskPriority.valueOf(parts.getOrNull(2) ?: TaskPriority.RANDOM.name),
                isCompleted = parts.getOrNull(3)?.toBoolean() ?: false
            )
        } ?: emptyList()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoApp(initialTasks: MutableList<Task>, onSaveTasks: (List<Task>) -> Unit) {
    var todos by remember { mutableStateOf(initialTasks) }
    var taskText by remember { mutableStateOf("") }
    var taskBeingEdited by remember { mutableStateOf<Task?>(null)}
    var showPriorityDialog by remember { mutableStateOf(false) }
    var selectedPriority by remember { mutableStateOf(TaskPriority.RANDOM) }


    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                if (taskText.isNotEmpty()) {
                    showPriorityDialog=true
                }
            }) {
                Icon(Icons.Filled.Add, contentDescription = "Add Task")
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = " Your Tasks 📌",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.Blue,
                    fontSize = MaterialTheme.typography.headlineLarge.fontSize
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            TaskInputField(
                text = taskText,
                onTextChange = { taskText = it },
                onImeAction = {
                    if (taskText.isNotEmpty()){
                        showPriorityDialog = true
                    }
                }
            )

            Spacer(modifier = Modifier.height(25.dp))

            //task list with lazy column
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(todos) { todo ->
                    TodoRow(
                        todo = todo,
                        onItemClicked = {
                            todos = todos.map { item ->
                                if (item.id == it.id) {
                                    item.copy(isCompleted = !item.isCompleted)
                                } else item
                            }.toMutableList()
                            onSaveTasks(todos)
                        },
                        onDeleteClicked = {
                            todos = todos.filter { item -> item.id != it.id }.toMutableList()
                            onSaveTasks(todos)
                        },
                        onEditClicked = { taskToEdit ->
                            taskBeingEdited= taskToEdit
                        }
                    )
                    Divider()
                }
            }

            if (showPriorityDialog) {
                PriorityDialog(
                    onDismiss = { showPriorityDialog = false },
                    onPrioritySelected = { priority ->
                        todos = (todos + Task(
                            id = if (todos.isEmpty()) 0 else todos.maxOf { it.id } + 1,
                            task = taskText,
                            priority = priority
                        )).toMutableList()
                        taskText = ""
                        onSaveTasks(todos)
                        showPriorityDialog = false
                    }
                )
            }

            EditTaskDialog(
                taskToEdit = taskBeingEdited,
                onDismiss = { taskBeingEdited = null },
                onSave = { newTaskText ->
                    todos = todos.map { item ->
                        if (item.id == taskBeingEdited?.id) {
                            item.copy(task = newTaskText)
                        } else item
                    }.toMutableList()
                    onSaveTasks(todos)
                    taskBeingEdited = null
                })
        }
    }
}

@Composable
fun TaskInputField(
    text: String,
    onTextChange: (String) -> Unit,
    onImeAction: () -> Unit
) {
    TextField(
        value = text,
        onValueChange = onTextChange,
        label = { Text("Enter task") },
        maxLines = 1,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onImeAction() })
    )
}

@Composable
fun TodoRow(
    todo: Task,
    onItemClicked: (Task) -> Unit,
    onDeleteClicked: (Task) -> Unit,
    onEditClicked: (Task) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(todo.priority.color.copy(alpha = 0.2f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = todo.isCompleted,
            onCheckedChange = { onItemClicked(todo) }
        )
        Text(
            text = todo.task,
            modifier = Modifier.weight(1f),
            style = TextStyle(
                textDecoration = if (todo.isCompleted) TextDecoration.LineThrough else null,
                color = if (todo.isCompleted) Color.Gray else Color.Black
            )
        )
        Text(
            text ="Priority: ${todo.priority.name}",
            color = todo.priority.color,
            fontSize = MaterialTheme.typography.bodySmall.fontSize
        )
        
        IconButton(onClick = { onEditClicked(todo)}) {
            Icon(Icons.Filled.Edit, contentDescription = "Edit Task", tint = Color.Blue)
        }
        IconButton(onClick = { onDeleteClicked(todo) }) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete Task", tint = Color.Red)
        }
    }
}



fun dropdownMenuItem(onClick: () -> Unit, interactionSource: @Composable () -> Unit) {
    TODO("Not yet implemented")
}
@Composable
fun LineUpApp() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {


        Text("Your Tasks 📌 ",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(16.dp)
        )
        TaskInputField()

    }
}


@Composable
fun TaskInputField() {
    var text by remember { mutableStateOf("") }

    TextField(
        value = text,
        onValueChange = { text = it },
        label = { Text("Enter task") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    )
}

@Composable
fun TaskScreen(today: TaskListScreen) {

    Button(onClick = { completeTask() }) {
        Text("Complete Task")
    }
}


fun completeTask() {
    TODO("Not yet implemented")
}

@Composable
fun EditTaskDialog(
    taskToEdit: Task?,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    if (taskToEdit != null) {
        var editedTaskText by remember { mutableStateOf(taskToEdit.task) }

        AlertDialog(
            onDismissRequest = onDismiss,
            confirmButton = {
                TextButton(onClick = {
                    onSave(editedTaskText)
                    onDismiss()
                },) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            },
            title = { Text("Edit Task") },
            text = {
                TextField(
                    value = editedTaskText,
                    onValueChange = { editedTaskText = it },
                    label = { Text("Task") }
                )
            }
        )
    }
}


@Composable
fun PriorityDialog(
    onDismiss: () -> Unit,
    onPrioritySelected: (TaskPriority) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Task Priority") },
        text = {
            Column {
                TaskPriority.values().forEach { priority ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .clickable { onPrioritySelected(priority) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(priority.color)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(priority.displayName, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )



    @Composable
    fun PriorityOption(
        priority: TaskPriority,
        onClick: () -> Unit
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clickable { onPrioritySelected(priority) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(priority.color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = priority.displayName, style = MaterialTheme.typography.bodyLarge)
        }
    }

    @Composable
    fun AddTaskScreen(onSaveTasks: (List<Task>) -> Unit) {
        var taskText by remember { mutableStateOf("") }
        var todos by remember { mutableStateOf(listOf<Task>()) }
        var showPriorityDialog by remember { mutableStateOf(false) }  // To show priority dialog
        var selectedPriority by remember { mutableStateOf(TaskPriority.RANDOM) }  // Default priority

        Column(modifier = Modifier.padding(16.dp)) {
            // Task Input Field
            TextField(
                value = taskText,
                onValueChange = { taskText = it },
                label = { Text("Enter Task") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (taskText.isNotEmpty()) {
                        showPriorityDialog = true
                    }
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Add Task")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Task List Display
            LazyColumn {
                items(todos) { todo ->
                    TodoRow(
                        todo = todo,
                        onItemClicked = { task ->
                            todos =
                                todos.map { if (it.id == task.id) it.copy(isCompleted = !it.isCompleted) else it }
                            onSaveTasks(todos)  // Persist changes
                        },
                        onDeleteClicked = { task ->
                            todos = todos.filter { it.id != task.id }
                            onSaveTasks(todos)  // Persist changes
                        },
                        onEditClicked = { task ->
                            // Handle task editing logic here
                        }
                    )
                }
            }

            // Priority Selection Dialog
            if (showPriorityDialog) {
                AlertDialog(
                    onDismissRequest = { showPriorityDialog = false },
                    title = { Text("Select Task Priority") },
                    text = {
                        Column {
                            TaskPriority.values().forEach { priority ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedPriority = priority
                                            showPriorityDialog =
                                                false

                                            // Add task with selected priority
                                            todos = todos + Task(
                                                id = todos.size,
                                                task = taskText,
                                                priority = selectedPriority
                                            )
                                            taskText = ""
                                            onSaveTasks(todos)  // Persist tasks
                                        }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selectedPriority == priority,
                                        onClick = {
                                            selectedPriority = priority
                                            showPriorityDialog =
                                                false

                                            // Add task with selected priority
                                            todos = todos + Task(
                                                id = todos.size,
                                                task = taskText,
                                                priority = selectedPriority
                                            )
                                            taskText = ""
                                            onSaveTasks(todos)  // Persist tasks
                                        }
                                    )
                                    Text(priority.name)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showPriorityDialog = false
                            }
                        ) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewTodoApp() {
    Column {
        TodoApp(initialTasks = mutableListOf(), onSaveTasks = {})
        LineUpApp()
    }
}

