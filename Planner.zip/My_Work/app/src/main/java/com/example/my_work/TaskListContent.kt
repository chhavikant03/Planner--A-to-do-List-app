package com.example.my_work

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@SuppressLint("MutableCollectionMutableState")
@Composable
fun <TaskListScreen> TaskListContent(screen: TaskListScreen, onTaskCheckedChange: Any) {
    // Define tasks state
    var taskList by remember { mutableStateOf(mutableListOf<Task>()) }
    var newTask by remember { mutableStateOf("") }

    Column {
        TextField(
            value = newTask,
            onValueChange = { newTask = it },
            label = { Text("Add new task") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            if (newTask.isNotEmpty()) {
                taskList.add(Task(id = taskList.size, task = newTask))
                newTask = ""
            }
        },
            modifier = Modifier.fillMaxWidth()
            ) {
            Text("Add Task")
        }
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(taskList) { task ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Checkbox(
                        checked = task.isCompleted,
                        onCheckedChange = {
                            taskList = taskList.map { t ->
                                if (t.id == task.id) t.copy(isCompleted = !t.isCompleted) else t
                            }.toMutableList()
                        }
                    )
                    Text(text = task.task, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        taskList = taskList.filter { it.id != task.id }.toMutableList()
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Task")
                    }
                }
            }
        }
    }
}
